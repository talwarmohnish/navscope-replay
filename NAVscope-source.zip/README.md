# NAVscope

NAVscope estimates the direction and size of a potential NAV move for the Direct Growth plans of Parag Parikh Flexi Cap Fund and HDFC Nifty 50 Index Fund. The dashboard shows the official NAV, the holdings disclosure date, the share of the portfolio matched to prices, and each stock’s contribution. Scenario prices are synthetic.

## Run locally

Use Node.js 22 or newer. From the extracted folder, run `node serve.mjs` and visit `http://127.0.0.1:4175`. The tracker uses the bundled official snapshots immediately while it checks for newer data. Change the port through `NAVSCOPE_PORT`. Run `node build.mjs` to produce a Cloudflare Worker at `dist/server/index.js`.

## Check an IndianAPI Free key

Sign in to [IndianAPI](https://indianapi.in/indian-stock-market), select the Free plan, and copy the key from your dashboard. On Windows, double-click `Open-NAVscope-Key-Setup.cmd` to open the local `.env.local` file in Notepad. Paste the key after `INDIANAPI_KEY=` and save. You can also edit `.env.local` in the project folder directly. The project excludes this file from Git.

Run `npm run quote:check` to make one request for Tata Consultancy Services. For another stock supply its name with `npm run quote:check -- "HDFC Bank"`. This command prints the provider's NSE and BSE prices when available. The Free endpoint may omit the quote timestamp. The command is for verifying API access and the response shape and does not update the dashboard. The dashboard does not spend IndianAPI credits during replay or automatic source refresh. [IndianAPI free-plan quickstart](https://indianapi.in/blog/get-your-api-key-and-make-your-first-call)

## Data and calculation

- **Official NAV.** The server reads the [AMFI bulk NAV file](https://portal.amfiindia.com/spages/NAVAll.txt) by ISIN for schemes `122639` and `119063`. The bundled NAVs for 20 November 2026 are ₹95.4585 for Parag Parikh and ₹252.6065 for HDFC.
- **Portfolio.** The server checks for newer [PPFAS](https://amc.ppfas.com/downloads/portfolio-disclosure/index.php) and [HDFC](https://www.hdfcfund.com/statutory-disclosure/portfolio/monthly-portfolio) monthly workbooks when the tracker is opened, with cached checks. Both integrations were verified against official 31 October 2026 workbooks. The bundled PPFAS snapshot contains 33 domestic equity holdings representing 75.25% of NAV. The bundled HDFC snapshot contains 50 stock holdings. Recurring background checks would need a scheduler and persistent storage.
- **Reported AUM.** The dashboard compares the fund houses' official September and October 2026 month-end scheme AUM in rupees and percent. The snapshots are bundled with source links in `aum-snapshots.json`. Automatic AUM ingestion and estimates of market-driven AUM are later milestones.
- **Stock prices.** Use the built-in simulated scenarios or import authorized INR quotes. This prototype has no continuous price provider. An eventual provider needs to supply the price, valuation-day reference close, matching security identifier and quote timestamp.
- **Model.** Multiply each disclosed stock weight by its price return from the NAV valuation close. The sum gives the estimated percentage change. The estimator holds unmatched positions flat and keeps the disclosed weights. No language model is used at runtime.

## Import prices

Use `isin,symbol,price,previous_close,base_date,as_of` as CSV headers. Supply an ISIN or stock symbol for every row. Repeat the official NAV date in `base_date` and the same quote timestamp, including its timezone, in `as_of`. `previous_close` must be from the `base_date` session. Delete the rows you do not have prices for. Prices stay in the current browser tab.

## Demo walkthrough

Open the dashboard and choose **Play replay**. The simulated session runs from 09:15 to 15:30 IST. Use **Next 5 min** to advance one sample at a time. The chart shows estimated NAV or a selected holding's simulated price in rupees, and the holdings table updates at the same time. The replay interpolates between scripted scenario points. Switch between the funds to compare how the same scenario affects them. Sort the stock table by **Biggest drag**, then open **Backend** to see the arithmetic and the official sources. The dashboard starts with your system color preference and remembers your Light or Dark choice in the browser. For PPFAS, the model holds separately disclosed arbitrage, REITs, foreign shares, debt and cash flat.

Here is a short explanation for judges.

> Our backend is Node.js with an HTTP endpoint. It loads the official NAV from AMFI and the latest disclosed holdings from the fund houses. The browser runs a deterministic JavaScript estimator. It multiplies each covered holding's weight by its price return from the NAV-aligned close, sums those contributions, and applies the result to the official NAV. We display coverage and dates because monthly holdings can lag what the fund owns today. In this replay, the official NAV, weights and AUM are dated snapshots, and the stock moves are synthetic. The live quote provider returned a test price with no verified quote time, so the demo uses the synthetic feed.

## GitHub Pages

Run `npm run build:pages` to refresh `docs/index.html`. In GitHub, set **Settings → Pages → Deploy from a branch → main → /docs**. The exported website includes dated fund snapshots and simulated market ticks. It runs in the browser, including CSV import. The Node.js backend runs locally with `npm start` and can be hosted separately for official source refresh. Keep `.env.local` on the machine that runs the quote test.

### Code map

- `serve.mjs` starts the local Node.js HTTP server.
- `worker.mjs` handles `/api/sources`, parses AMFI NAV, and caches dated results from AMFI and the fund houses.
- `site/market.mjs` validates price snapshots and calculates the NAV estimate and holding contributions.
- `site/app.mjs` handles the dashboard, replay controls, and presentation of the calculated results.
- `quote-check.mjs` tests an IndianAPI key with a single quote request.

Estimates are indicative and for education. Actual fund positions, costs, dividends and corporate actions can cause differences. This project is independent of the fund houses and AMFI. It uses browser APIs and Node.js with no third-party runtime packages.
