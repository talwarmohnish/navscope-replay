import { decodeEntities, readSmall, validIsin, workbookRows } from "./hdfc-portfolio.mjs";

export const ppfasIndexUrl = "https://amc.ppfas.com/downloads/portfolio-disclosure/index.php";
const ppfasIndexOrigin = new URL(ppfasIndexUrl).origin;
const ppfasMonths = "January February March April May June July August September October November December".split(" ");
const ppfasFilePattern = /^\/downloads\/portfolio-disclosure\/(\d{4})\/PPFCF_PPFAS_Monthly_Portfolio_Report_([a-z]+)_(\d{1,2})_(\d{4})\.xlsx$/i;

function ppfasAsOfDate(monthName, day, year) {
  const month = ppfasMonths.findIndex(value => value.toLowerCase() === monthName.toLowerCase());
  if (month < 0 || Number(day) !== new Date(Date.UTC(Number(year), month + 1, 0)).getUTCDate()) return null;
  return year + "-" + String(month + 1).padStart(2, "0") + "-" + day;
}

function ppfasWorkbookLink(value) {
  try {
    const url = new URL(decodeEntities(value), ppfasIndexUrl);
    if (url.origin !== ppfasIndexOrigin || url.username || url.password) return null;
    const match = decodeURIComponent(url.pathname).match(ppfasFilePattern);
    if (!match || match[1] !== match[4]) return null;
    const asOf = ppfasAsOfDate(match[2], match[3], match[4]);
    return asOf && { asOf, sourceUrl: url.href };
  } catch {
    return null;
  }
}

export function latestPpfasWorkbook(html) {
  return [...html.matchAll(/\bhref\s*=\s*(?:"([^"]*)"|'([^']*)')/gi)]
    .map(match => ppfasWorkbookLink(match[1] ?? match[2]))
    .filter(Boolean)
    .sort((a, b) => b.asOf.localeCompare(a.asOf))[0] ?? null;
}

function ppfasCellText(row, column) {
  return row.get(column)?.text.replace(/\s+/g, " ").trim() ?? "";
}

function ppfasPercent(cell) {
  const value = cell?.text.replace(/[,%$ ]/g, "");
  if (!value) return NaN;

  // The AMC workbook stores numeric percentages as Excel ratios and renders its
  // immaterial entries as literal text with an explicit percent suffix.
  const number = Number(value) * (cell.text.includes("%") ? 1 : 100);
  return Number.isFinite(number) ? Number(number.toFixed(6)) : NaN;
}

export async function parsePpfasWorkbook(bytes, expectedDate) {
  for await (const rows of workbookRows(bytes)) {
    const topLabels = rows.slice(0, 8).flatMap(row => [...row.values()].map(cell => cell.text));
    if (!topLabels.some(label => /^Parag Parikh Flexi Cap Fund\b/i.test(label.trim()))) continue;
    const reportDate = topLabels.find(label => /^Monthly Portfolio Statement as on\b/i.test(label.trim()))
      ?.match(/\bas on\s+([a-z]+)\s+(\d{1,2}),\s*(\d{4})/i);
    const asOf = reportDate && ppfasAsOfDate(reportDate[1], reportDate[2], reportDate[3]);
    if (!asOf || (expectedDate && asOf !== expectedDate)) throw new Error("PPFAS statement date mismatch");

    const header = rows.find(row => [...row.values()].some(cell => cell.text === "ISIN"));
    if (!header) throw new Error("PPFAS worksheet is missing the portfolio headers");

    const findColumn = pattern => [...header.keys()].find(column => pattern.test(ppfasCellText(header, column)));
    const nameColumn = findColumn(/^Name of the Instrument$/i);
    const isinColumn = findColumn(/^ISIN$/i);
    const sectorColumn = findColumn(/Industry\s*\/\s*Rating/i);
    const weightColumn = findColumn(/%\s*to\s*Net\s*Assets/i);
    if (!nameColumn || !isinColumn || !sectorColumn || !weightColumn) throw new Error("PPFAS portfolio columns changed");

    const domestic = rows.findIndex(row => /^Equity & Equity related$/i.test(ppfasCellText(row, nameColumn)));
    const start = domestic < 0 ? -1 : rows.findIndex((row, index) =>
      index > domestic && /^\(a\)\s*listed\b/i.test(ppfasCellText(row, nameColumn)));
    const end = start < 0 ? -1 : rows.findIndex((row, index) =>
      index > start && /^sub\s*total$/i.test(ppfasCellText(row, nameColumn)));
    if (start < 0 || end < 0) throw new Error("PPFAS domestic listed equity section is missing");

    const holdings = [];
    const ids = new Set();
    for (const row of rows.slice(start + 1, end)) {
      const name = ppfasCellText(row, nameColumn);
      const isin = ppfasCellText(row, isinColumn).toUpperCase();
      if (!name && !isin) continue;
      const weightPct = ppfasPercent(row.get(weightColumn));
      if (!name || !validIsin(isin) || ids.has(isin) || !Number.isFinite(weightPct) || weightPct < 0 || weightPct > 100) {
        throw new Error("Invalid PPFAS listed equity position");
      }
      ids.add(isin);
      if (weightPct > 0) holdings.push({ isin, name, sector: ppfasCellText(row, sectorColumn), weightPct });
    }

    const disclosedEquityWeightPct = ppfasPercent(rows[end].get(weightColumn));
    const sum = holdings.reduce((total, holding) => total + holding.weightPct, 0);
    const tolerance = ids.size * 0.005 + 0.01;
    if (holdings.length === 0 || !Number.isFinite(disclosedEquityWeightPct)
      || disclosedEquityWeightPct <= 0 || disclosedEquityWeightPct > 100
      || Math.abs(disclosedEquityWeightPct - sum) > tolerance) {
      throw new Error("PPFAS positions do not reconcile with the domestic equity subtotal");
    }

    holdings.sort((a, b) => b.weightPct - a.weightPct);
    return { asOf, holdings, disclosedEquityWeightPct };
  }
  throw new Error("PPFAS workbook does not contain the Parag Parikh Flexi Cap Fund portfolio");
}

export async function fetchPpfasPortfolio(fetcher = fetch) {
  const options = () => ({ redirect: "error", signal: AbortSignal.timeout(7500) });
  const listing = await readSmall(await fetcher(ppfasIndexUrl, options()));
  const latest = latestPpfasWorkbook(new TextDecoder().decode(listing));
  if (!latest) throw new Error("The PPFAS monthly listing has no supported Flexi Cap workbook link");
  const bytes = await readSmall(await fetcher(latest.sourceUrl, options()));
  const portfolio = await parsePpfasWorkbook(bytes, latest.asOf);
  return { ...portfolio, sourceUrl: latest.sourceUrl, indexUrl: ppfasIndexUrl, sourceType: "AMC monthly portfolio" };
}

