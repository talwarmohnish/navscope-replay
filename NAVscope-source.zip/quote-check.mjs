import { loadEnvFile } from "node:process";
import { checkIndianApiQuote, IndianApiQuoteError } from "./indianapi.mjs";

function loadLocalSettings() {
  try {
    loadEnvFile(".env.local");
  } catch (error) {
    if (error.code !== "ENOENT") throw new Error("Could not read .env.local.");
  }
}

function printPrice(exchange, price) {
  if (price !== null) console.log(`${exchange} ₹${price.toFixed(2)}`);
}

try {
  loadLocalSettings();
  const name = process.argv.slice(2).join(" ").trim() || "Tata Consultancy Services";
  const quote = await checkIndianApiQuote({ apiKey: process.env.INDIANAPI_KEY, name });
  console.log(`${quote.source} responded for ${quote.name}.`);
  printPrice("NSE", quote.nsePrice);
  printPrice("BSE", quote.bsePrice);
  console.log(quote.quoteTimestamp ? `Provider quote time ${quote.quoteTimestamp}` : "The provider did not supply a quote timestamp.");
  console.log("This check fetched one quote. The dashboard still uses replay or imported prices.");
} catch (error) {
  if (error instanceof IndianApiQuoteError && error.code === "MISSING_KEY") {
    console.error("Set INDIANAPI_KEY in .env.local, then run npm run quote:check again.");
  } else {
    console.error(error instanceof IndianApiQuoteError ? error.message : "The quote check could not start. Check the project folder and .env.local.");
  }
  process.exitCode = 1;
}
