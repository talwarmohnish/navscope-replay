const navFeed = "https://portal.amfiindia.com/spages/NAVAll.txt";
const monthCodes = ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"];
const fundCatalog = {
  ppfas: {
    fund: { id: "ppfas", house: "PPFAS", name: "Parag Parikh Flexi Cap Fund", code: "122639", isin: "INF879O01027" },
    snapshotNav: 95.4585,
    portfolio: snapshotPpfasPortfolio,
    loadPortfolio: getPpfasPortfolio,
  },
  hdfc: {
    fund: { id: "hdfc", house: "HDFC", name: "HDFC Nifty 50 Index Fund", code: "119063", isin: "INF179K01WM1" },
    snapshotNav: 252.6065,
    portfolio: snapshotHdfcPortfolio,
    loadPortfolio: getHdfcPortfolio,
  },
};
const symbolLookup = new Map(snapshotHdfcPortfolio.holdings.map(({ name, symbol }) => [fundNameKey(name), symbol]));

function snapshotFor(source) {
  return {
    fund: source.fund,
    nav: { value: source.snapshotNav, date: "2026-11-20", sourceUrl: navFeed, status: "snapshot" },
    portfolio: { ...source.portfolio, status: "snapshot" },
    aum: reportedAum[source.fund.id],
  };
}

function fundNameKey(name) {
  return name.toLowerCase().replace(/\b(limited|ltd)\b/g, "").replace(/&/g, "and").replace(/[^a-z0-9]/g, "");
}

export function parseAmfiNav(body, fund) {
  const rows = body.replace(/^\uFEFF/, "").split(/\r?\n/);
  const header = rows.find((line) => line.startsWith("Scheme Code;"));
  if (!header) throw new Error("AMFI feed layout changed");
  const headers = header.split(";").map((column) => column.trim().toLowerCase());
  const navColumn = headers.indexOf("net asset value");
  const dateColumn = headers.indexOf("date");
  const isinColumn = headers.findIndex((value) => value.includes("isin growth"));
  if (navColumn < 0 || dateColumn < 0 || isinColumn < 0) throw new Error("AMFI feed layout changed");
  for (const row of rows) {
    if (!row.startsWith(`${fund.code};`) && !row.includes(`;${fund.isin};`)) continue;
    const cells = row.split(";");
    if (cells[isinColumn] !== fund.isin) continue;
    const value = Number(cells[navColumn]);
    const date = cells[dateColumn]?.trim().match(/^(\d{1,2})-([A-Za-z]{3})-(\d{4})$/);
    if (!(Number.isFinite(value) && value > 0 && date)) continue;
    const month = monthCodes.indexOf(date[2].toLowerCase()) + 1;
    if (!month) continue;
    const iso = `${date[3]}-${String(month).padStart(2, "0")}-${date[1].padStart(2, "0")}`;
    const receivedDate = new Date(`${iso}T00:00:00Z`);
    if (!Number.isFinite(receivedDate.valueOf()) || !receivedDate.toISOString().startsWith(iso)) continue;
    return { value, date: iso, sourceUrl: navFeed };
  }
  throw new Error("Scheme NAV missing from AMFI feed");
}

async function getAmfiNav(fund) {
  const response = await fetch(navFeed, { signal: AbortSignal.timeout(6000) });
  if (!response.ok) throw new Error("AMFI feed unavailable");
  return parseAmfiNav(await response.text(), fund);
}

async function getHdfcPortfolio() {
  const deadline = AbortSignal.timeout(8500);
  const timedFetch = (url, config) => fetch(url, { ...config, signal: AbortSignal.any([deadline, config.signal]) });
  const portfolio = await fetchPortfolio(timedFetch);
  if (portfolio.disclosedEquityWeightPct > 100.3) throw new Error("Reported equity exposure is outside this estimate’s range");
  for (const holding of portfolio.holdings) {
    holding.symbol = symbolLookup.get(fundNameKey(holding.name));
  }
  return portfolio;
}

async function getPpfasPortfolio() {
  return fetchPpfasPortfolio(fetch);
}

const memoryCache = new Map();

async function readCache(key) {
  try {
    if (globalThis.caches?.default) {
      const cached = await caches.default.match(key);
      if (cached) return await cached.json();
    }
  } catch { /* Cache availability varies by preview environment. */ }
  return memoryCache.get(key);
}

async function writeCache(key, entry) {
  if (globalThis.caches?.default) {
    try {
      await caches.default.put(key, Response.json(entry, { headers: { "Cache-Control": "public, max-age=5184000" } }));
      return;
    } catch { /* Fall back to memory for this worker instance. */ }
  }
  memoryCache.set(key, entry);
}

async function loadSource({ origin, type, maxAge, dateKey, fallback, load, force }) {
  const key = new URL(`/__source-cache/${type}-1`, origin).href;
  const previous = await readCache(key);
  const lastGood = previous?.value ?? fallback;
  const elapsed = Date.now() - (previous?.lastAttempt ?? 0);
  if (previous && elapsed < (force ? 10_000 : maxAge)) return lastGood;
  const lastAttempt = Date.now();
  let value = lastGood;
  try {
    const next = await load();
    if (next[dateKey] >= lastGood[dateKey]) value = { ...next, status: "verified", checkedAt: new Date(lastAttempt).toISOString() };
  } catch (error) {
    if (value.status === "verified") value = { ...value, status: "cached" };
    console.warn(`${type} refresh unavailable: ${error.message}`);
  }
  // A failed upstream refresh keeps the last verified snapshot and backs off.
  await writeCache(key, { value, lastAttempt });
  return value;
}

const security = {
  "X-Content-Type-Options": "nosniff",
  "Referrer-Policy": "strict-origin-when-cross-origin",
  "Content-Security-Policy": "default-src 'self'; style-src 'self'; script-src 'self'; base-uri 'none'; object-src 'none'; form-action 'none'",
};

export default {
  async fetch(request) {
    const url = new URL(request.url);
    if (request.method !== "GET") return new Response("Method not allowed", { status: 405, headers: { Allow: "GET", ...security } });
    const jsonHeaders = { "Cache-Control": "no-store", ...security };
    if (url.pathname === "/api/bootstrap" || url.pathname === "/api/sources") {
      const selected = url.searchParams.get("fund") ?? "ppfas";
      if (!Object.hasOwn(fundCatalog, selected)) return Response.json({ error: "Fund not found" }, { status: 404, headers: jsonHeaders });
      const source = fundCatalog[selected];
      const fallback = snapshotFor(source);
      if (url.pathname === "/api/bootstrap") return Response.json(fallback, { headers: jsonHeaders });
      const force = url.searchParams.get("refresh") === "1";
      const origin = url.origin;
      const [nav, portfolio] = await Promise.all([
        loadSource({ origin, type: `${selected}-nav`, maxAge: 15 * 60_000, dateKey: "date", fallback: fallback.nav, load: () => getAmfiNav(source.fund), force }),
        loadSource({ origin, type: `${selected}-portfolio`, maxAge: 12 * 60 * 60_000, dateKey: "asOf", fallback: fallback.portfolio, load: source.loadPortfolio, force }),
      ]);
      return Response.json({ fund: source.fund, nav, portfolio, aum: fallback.aum }, { headers: jsonHeaders });
    }
    const asset = assets[url.pathname];
    if (!Object.hasOwn(assets, url.pathname)) return new Response("Page not found", { status: 404, headers: security });
    return new Response(asset.body, { headers: { "Content-Type": asset.contentType, "Cache-Control": "no-cache", ...security } });
  },
};
