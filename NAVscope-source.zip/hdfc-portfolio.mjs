const indexUrl = "https://www.hdfcfund.com/statutory-disclosure/portfolio/monthly-portfolio";
const scheme = "HDFC Nifty 50 Index Fund";
const months = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December",
];
const decoder = new TextDecoder();
const allowedHosts = new Set(["files.hdfcfund.com", "www.hdfcfund.com"]);
const maxBytes = 4 * 1024 * 1024;

function decodeEntities(text) {
  const named = { amp: "&", lt: "<", gt: ">", quot: '"', apos: "'", nbsp: " " };
  return text.replace(/&(#x[\da-f]+|#\d+|[a-z]+);/gi, (entity, key) => {
    if (!key.startsWith("#")) return named[key] ?? entity;
    const point = key[1].toLowerCase() === "x"
      ? Number.parseInt(key.slice(2), 16)
      : Number.parseInt(key.slice(1), 10);
    return point <= 0x10ffff ? String.fromCodePoint(point) : entity;
  });
}

function allowedWorkbookUrl(value) {
  try {
    const url = new URL(decodeEntities(value), indexUrl);
    return url.protocol === "https:" && !url.port && !url.username && !url.password
      && allowedHosts.has(url.hostname) && /\.xlsx$/i.test(url.pathname) ? url : null;
  } catch {
    return null;
  }
}

function reportDate(filename) {
  const text = decodeURIComponent(filename).replace(/[_%+]+/g, " ");
  const match = text.match(/hdfc\s+nifty\s*50\s+index\s+fund\b.*?(\d{1,2})(?:st|nd|rd|th)?[\s-]+([a-z]+)[\s,-]+(\d{4})/i);
  if (!match) return null;
  const [, day, month, year] = match;
  const monthIndex = months.findIndex(value => value.toLowerCase().startsWith(month.toLowerCase()));
  if (month.length < 3 || monthIndex === -1 || Number(day) < 1
    || Number(day) > new Date(Date.UTC(Number(year), monthIndex + 1, 0)).getUTCDate()) return null;
  return year + "-" + String(monthIndex + 1).padStart(2, "0") + "-" + day.padStart(2, "0");
}

export function discoverWorkbooks(html) {
  const cleaned = html.replace(/\\+(?:"|\/|u002f|u0026|u003a)/gi, match => ({
    '"': '"', "/": "/", u002f: "/", u0026: "&", u003a: ":",
  })[match.replace(/^\\+/, "").toLowerCase()]);
  const found = new Map();
  const candidates = cleaned.matchAll(/(?:https?:\/\/(?:files\.|www\.)hdfcfund\.com)?\/[^\s"'<>\\]*?(?:%20|[+ ])*(?:HDFC|hdfc)[^"'<>\\]*?\.xlsx(?:\?[^"'<>\\\s]+)?/gi);
  for (const [candidate] of candidates) {
    const url = allowedWorkbookUrl(candidate);
    if (!url) continue;
    let asOf;
    try {
      asOf = reportDate(url.pathname.split("/").at(-1));
    } catch {
      continue;
    }
    if (asOf) found.set(url.href, { sourceUrl: url.href, asOf });
  }
  return [...found.values()].sort((a, b) => b.asOf.localeCompare(a.asOf));
}

function possibleWorkbooks(now) {
  const utcIndia = new Date(now.getTime() + 330 * 60 * 1000);
  const year = utcIndia.getUTCFullYear();
  const month = utcIndia.getUTCMonth();
  const candidates = [];
  for (const offset of [0, 1]) {
    const report = new Date(Date.UTC(year, month - offset, 0));
    const asOf = report.toISOString().slice(0, 10);
    const nextMonth = new Date(Date.UTC(year, month - offset, 1)).toISOString().slice(0, 7);
    const name = "Monthly " + scheme + " - " + report.getUTCDate()
      + " " + months[report.getUTCMonth()] + " " + report.getUTCFullYear() + ".xlsx";
    for (const directory of [nextMonth, asOf.slice(0, 7)]) {
      candidates.push({
        sourceUrl: "https://files.hdfcfund.com/s3fs-public/" + directory + "/" + encodeURIComponent(name),
        asOf,
      });
    }
  }
  return candidates;
}

async function readSmall(response) {
  if (!response.ok || !response.body) throw new Error("Source response " + response.status);
  if (Number(response.headers.get("content-length")) > maxBytes) throw new Error("Source file is too large");
  const reader = response.body.getReader();
  const chunks = [];
  let bytesRead = 0;
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    bytesRead += value.byteLength;
    if (bytesRead > maxBytes) {
      await reader.cancel();
      throw new Error("Source file is too large");
    }
    chunks.push(value);
  }
  const bytes = new Uint8Array(bytesRead);
  let offset = 0;
  for (const chunk of chunks) {
    bytes.set(chunk, offset);
    offset += chunk.byteLength;
  }
  return bytes;
}

function readArchive(bytes) {
  if (bytes.byteLength < 22 || bytes.byteLength > maxBytes) throw new Error("Invalid workbook size");
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const u16 = offset => view.getUint16(offset, true);
  const u32 = offset => view.getUint32(offset, true);

  let end = bytes.byteLength - 22;
  const limit = Math.max(0, end - 65535);
  while (end >= limit && (u32(end) !== 0x06054b50 || end + 22 + u16(end + 20) !== bytes.byteLength)) {
    end--;
  }
  if (end < limit || u16(end + 4) || u16(end + 6)) throw new Error("Invalid workbook ZIP directory");

  const entries = new Map();
  const count = u16(end + 10);
  let cursor = u32(end + 16);
  for (let index = 0; index < count; index++) {
    if (cursor + 46 > end || u32(cursor) !== 0x02014b50) throw new Error("Invalid workbook ZIP entry");
    const method = u16(cursor + 10);
    const compressedSize = u32(cursor + 20);
    const size = u32(cursor + 24);
    const nameLength = u16(cursor + 28);
    const local = u32(cursor + 42);
    const name = decoder.decode(bytes.subarray(cursor + 46, cursor + 46 + nameLength));
    const encrypted = u16(cursor + 8) & 1;
    cursor += 46 + nameLength + u16(cursor + 30) + u16(cursor + 32);
    if (/^xl\/(?:styles\.xml|sharedStrings\.xml|worksheets\/sheet\d+\.xml)$/.test(name)) {
      if (encrypted || size > maxBytes || local + 30 > end || u32(local) !== 0x04034b50) {
        throw new Error("Unsupported workbook ZIP entry");
      }
      const start = local + 30 + u16(local + 26) + u16(local + 28);
      if (start + compressedSize > end) throw new Error("Truncated workbook ZIP entry");
      entries.set(name, { method, size, data: bytes.subarray(start, start + compressedSize) });
    }
  }

  return {
    worksheets: [...entries.keys()].filter(name => name.startsWith("xl/worksheets/")),
    async read(name) {
      const entry = entries.get(name);
      if (!entry) return "";
      if (entry.method === 0 && entry.data.byteLength === entry.size) return decoder.decode(entry.data);
      if (entry.method !== 8) throw new Error("Unsupported workbook compression");
      const content = new Blob([entry.data]).stream().pipeThrough(new DecompressionStream("deflate-raw"));
      const output = await readSmall(new Response(content));
      if (output.byteLength !== entry.size) throw new Error("Workbook entry length mismatch");
      return decoder.decode(output);
    },
  };
}

function attribute(tag, name) {
  const match = tag.match(new RegExp("(?:^|\\s)" + name + "=(?:\"([^\"]*)\"|'([^']*)')", "i"));
  return match ? decodeEntities(match[1] ?? match[2]) : "";
}

function readText(xml) {
  const text = [...xml.matchAll(/<t(?:\s[^>]*)?>([^]*?)<\/t>/g)].map(match => match[1]).join("");
  return decodeEntities(text);
}

function percentStyles(xml) {
  const numberFormats = new Set([9, 10]);
  for (const [format] of xml.matchAll(/<numFmt\s[^>]*>/g)) {
    if (attribute(format, "formatCode").replace(/"[^"]*"|\\./g, "").includes("%")) {
      numberFormats.add(Number(attribute(format, "numFmtId")));
    }
  }
  const styles = xml.match(/<cellXfs(?:\s[^>]*)?>([^]*?)<\/cellXfs>/)?.[1] ?? "";
  return [...styles.matchAll(/<xf(?:\s[^>]*)?>/g)]
    .map(([style]) => numberFormats.has(Number(attribute(style, "numFmtId"))));
}

function readRows(xml, strings, styles) {
  return [...xml.matchAll(/<row(?:\s[^>]*)?>([^]*?)<\/row>/g)].map(([, row]) => {
    const cells = new Map();
    for (const [, attrs, data] of row.matchAll(/<c(\s[^>]*?)(?:\/>|>([^]*?)<\/c>)/g)) {
      const column = attribute(attrs, "r").match(/^[A-Z]+/)?.[0];
      if (!column || !data) continue;
      const type = attribute(attrs, "t");
      const value = decodeEntities(data.match(/<v(?:\s[^>]*)?>([^]*?)<\/v>/)?.[1] ?? "");
      const text = type === "s" ? strings[Number(value)] : type === "inlineStr" ? readText(data) : value;
      cells.set(column, { text: (text ?? "").trim(), percent: styles[Number(attribute(attrs, "s"))] === true });
    }
    return cells;
  });
}

function validIsin(isin) {
  // Expand letters per ISO 6166, then validate the Luhn check digit.
  if (!/^INE[A-Z0-9]{8}\d$/.test(isin)) return false;
  const digits = isin.replace(/[A-Z]/g, letter => String(letter.charCodeAt(0) - 55));
  const sum = [...digits].reverse().reduce((total, char, index) => {
    const value = Number(char) * (index % 2 ? 2 : 1);
    return total + (value > 9 ? value - 9 : value);
  }, 0);
  return sum % 10 === 0;
}

function extractHoldings(rows) {
  // Match the whole fund title and leave similar products such as its ETF and equal-weight fund excluded.
  const schemeTitle = /\bHDFC\s+(?:NIFTY\s*50\s+INDEX\s+FUND|INDEX\s+FUND\s*[-–]\s*NIFTY\s*50\s+PLAN)\b/i;
  if (!rows.slice(0, 20).some(row => [...row.values()]
    .some(({ text }) => schemeTitle.test(text)))) return null;

  const headerIndex = rows.findIndex(row => {
    const values = [...row.values()].map(({ text }) => text.toLowerCase().replace(/\s+/g, " "));
    return values.some(text => /\bisin\b/.test(text))
      && values.some(text => /(?:%|percent).*(?:nav|net\s*assets)/.test(text))
      && values.some(text => /instrument|company|security/.test(text));
  });
  if (headerIndex < 0) return null;

  const columns = [...rows[headerIndex]];
  const column = pattern => columns.find(([, { text }]) => pattern.test(text.replace(/\s+/g, " ")))?.[0];
  const nameColumn = column(/instrument|company|security/i);
  const isinColumn = column(/\bisin\b/i);
  const weightColumn = column(/(?:%|percent).*(?:nav|net\s*assets)/i);
  const sectorColumn = column(/industry|sector/i);
  const holdings = new Map();

  for (const row of rows.slice(headerIndex + 1)) {
    const isin = row.get(isinColumn)?.text.toUpperCase();
    const name = row.get(nameColumn)?.text;
    const weight = row.get(weightColumn);
    if (!isin || !name || !validIsin(isin) || !weight || !weight.text) continue;
    const weightPct = Number(weight.text.replace(/[%\s,]/g, "")) * (weight.percent && !weight.text.includes("%") ? 100 : 1);
    if (!Number.isFinite(weightPct) || weightPct <= 0 || weightPct > 100) continue;
    if (holdings.has(isin)) throw new Error("Duplicate equity holding in workbook");
    holdings.set(isin, { isin, name, sector: row.get(sectorColumn)?.text || "Unclassified", weightPct });
  }

  const result = [...holdings.values()];
  // The target scheme normally holds around 50 equities near 100% of NAV.
  // Accept proportional numeric storage for worksheets without Excel percentage styles.
  const total = result.reduce((sum, item) => sum + item.weightPct, 0);
  if (total >= 0.95 && total <= 1.05) {
    result.forEach(item => { item.weightPct *= 100; });
  }
  const disclosedEquityWeightPct = result.reduce((sum, item) => sum + item.weightPct, 0);
  if (result.length < 45 || result.length > 55 || disclosedEquityWeightPct < 95 || disclosedEquityWeightPct > 105) {
    return null;
  }
  result.sort((a, b) => b.weightPct - a.weightPct);
  return { holdings: result, disclosedEquityWeightPct };
}

export async function parseWorkbook(bytes) {
  for await (const rows of workbookRows(bytes)) {
    const match = extractHoldings(rows);
    if (match) return match;
  }
  throw new Error("Workbook does not contain a complete HDFC Nifty 50 Index Fund equity portfolio");
}

export async function* workbookRows(bytes) {
  const archive = readArchive(bytes);
  const strings = [...(await archive.read("xl/sharedStrings.xml")).matchAll(/<si(?:\s[^>]*)?>([^]*?)<\/si>/g)]
    .map(([, text]) => readText(text));
  const styles = percentStyles(await archive.read("xl/styles.xml"));
  for (const path of archive.worksheets) {
    yield readRows(await archive.read(path), strings, styles);
  }
}

export { decodeEntities, readSmall, validIsin };

export async function fetchPortfolio(fetcher = fetch, { workbookUrl, now = new Date() } = {}) {
  const fetchOptions = () => ({ redirect: "error", signal: AbortSignal.timeout(7000) });
  let candidates = [];
  if (workbookUrl) {
    const url = allowedWorkbookUrl(workbookUrl);
    const asOf = url && reportDate(url.pathname.split("/").at(-1));
    if (!asOf) throw new Error("Expected an official HDFC Nifty 50 Index Fund workbook URL");
    candidates = [{ sourceUrl: url.href, asOf }];
  } else {
    try {
      const response = await fetcher(indexUrl, fetchOptions());
      candidates = discoverWorkbooks(decoder.decode(await readSmall(response)));
    } catch {
      // If the live listing is unavailable, try the recent public file locations.
    }
    const known = new Set(candidates.map(candidate => candidate.sourceUrl));
    for (const candidate of possibleWorkbooks(now)) {
      if (!known.has(candidate.sourceUrl)) candidates.push(candidate);
    }
    candidates.sort((a, b) => b.asOf.localeCompare(a.asOf));
  }

  for (const { sourceUrl, asOf } of candidates.slice(0, 6)) {
    try {
      const response = await fetcher(sourceUrl, fetchOptions());
      const portfolio = await parseWorkbook(await readSmall(response));
      return { asOf, sourceUrl, indexUrl, sourceType: "AMC monthly portfolio", ...portfolio };
    } catch {
      // Invalid or missing workbooks leave the last verified snapshot eligible for use.
    }
  }
  throw new Error("Could not retrieve and validate an official HDFC monthly workbook");
}

