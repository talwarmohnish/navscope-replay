const stockEndpoint = "https://stock.indianapi.in/stock";
const timeoutMs = 8_000;

export class IndianApiQuoteError extends Error {
  constructor(code, message) {
    super(message);
    this.name = "IndianApiQuoteError";
    this.code = code;
  }
}

function readPrice(value) {
  const amount = typeof value === "string" && /^\d+(?:\.\d+)?$/.test(value.trim())
    ? Number(value)
    : value;
  return typeof amount === "number" && Number.isFinite(amount) && amount > 0 ? amount : null;
}

function readCompanyName(value) {
  const name = typeof value === "string" ? value.trim() : "";
  return name.length > 0 && name.length <= 120 && !/[\u0000-\u001f\u007f]/.test(name) ? name : "";
}

function readQuoteTimestamp(value) {
  // The free endpoint does not currently document a quote time. Only accept an explicit one.
  if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})$/.test(value)) return null;
  const instant = Date.parse(value);
  return Number.isFinite(instant) ? new Date(instant).toISOString() : null;
}

export async function checkIndianApiQuote({ apiKey, name, fetcher = fetch }) {
  const key = typeof apiKey === "string" ? apiKey.trim() : "";
  if (!key) {
    throw new IndianApiQuoteError("MISSING_KEY", "Set INDIANAPI_KEY on the server before checking a quote.");
  }
  if (!/^[!-~]+$/.test(key)) {
    throw new IndianApiQuoteError("AUTH", "The configured IndianAPI key has an invalid format.");
  }
  const company = readCompanyName(name);
  if (!company || company.includes(key)) {
    throw new IndianApiQuoteError("INVALID_NAME", "Enter a stock name of up to 120 characters.");
  }

  const url = new URL(stockEndpoint);
  url.searchParams.set("name", company);
  const signal = AbortSignal.timeout(timeoutMs);

  let response;
  try {
    response = await fetcher(url, {
      method: "GET",
      headers: { Accept: "application/json", "X-Api-Key": key },
      cache: "no-store",
      redirect: "error",
      signal,
    });
  } catch {
    if (signal.aborted) throw new IndianApiQuoteError("TIMEOUT", "IndianAPI timed out. Try again in a moment.");
    throw new IndianApiQuoteError("UPSTREAM", "The IndianAPI quote service could not be reached.");
  }

  if (response.status === 401 || response.status === 403) {
    throw new IndianApiQuoteError("AUTH", "IndianAPI rejected the key or plan. Check that the Free stock API subscription is active.");
  }
  if (response.status === 404) {
    throw new IndianApiQuoteError("AUTH", "The IndianAPI quote endpoint is unavailable for this key or plan.");
  }
  if (response.status === 429) {
    throw new IndianApiQuoteError("RATE_LIMIT", "IndianAPI reached a rate limit or your plan's quote credits are exhausted.");
  }
  if (!response.ok) {
    throw new IndianApiQuoteError("UPSTREAM", "IndianAPI could not complete the quote check.");
  }

  let body;
  try {
    body = await response.json();
  } catch {
    if (signal.aborted) throw new IndianApiQuoteError("TIMEOUT", "IndianAPI timed out. Try again in a moment.");
    throw new IndianApiQuoteError("INVALID_RESPONSE", "IndianAPI returned an unreadable quote response.");
  }

  if (body?.error === "Stock not found") {
    throw new IndianApiQuoteError("NOT_FOUND", "IndianAPI could not find that stock. Try its full company name or symbol.");
  }
  if (body?.error) {
    throw new IndianApiQuoteError("UPSTREAM", "IndianAPI could not complete the quote check.");
  }

  const nsePrice = readPrice(body?.currentPrice?.NSE);
  const bsePrice = readPrice(body?.currentPrice?.BSE);
  if (nsePrice === null && bsePrice === null) {
    throw new IndianApiQuoteError("INVALID_RESPONSE", "IndianAPI returned no usable NSE or BSE price for that stock.");
  }

  const companyName = readCompanyName(body?.companyName);
  return {
    name: companyName && !companyName.includes(key) ? companyName : company,
    nsePrice,
    bsePrice,
    source: "IndianAPI",
    quoteTimestamp: readQuoteTimestamp(body?.quoteTimestamp),
  };
}
