const csvColumns = ["isin", "symbol", "price", "previous_close", "base_date", "as_of"];

function normalizeId(value) {
  return typeof value === "string" ? value.trim().toUpperCase() : "";
}

function validDate(value) {
  if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const parsed = new Date(`${value}T00:00:00Z`);
  return Number.isFinite(parsed.getTime()) && parsed.toISOString().startsWith(value);
}

function marketSessionDate(asOf) {
  const timestampPattern = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(?::\d{2}(?:\.\d{1,3})?)?(?:Z|[+-]\d{2}:\d{2})$/;
  if (typeof asOf !== "string" || !timestampPattern.test(asOf) || !validDate(asOf.slice(0, 10))) {
    throw new Error("Use an as-of timestamp with a timezone, for example 2026-11-20T14:30:00+05:30.");
  }
  const timestamp = Date.parse(asOf);
  if (!Number.isFinite(timestamp)) throw new Error("The quote timestamp is invalid.");
  return new Date(timestamp + 330 * 60_000).toISOString().slice(0, 10);
}

function indexQuotes(quotes) {
  const byIsin = new Map();
  const bySymbol = new Map();
  for (const quote of quotes) {
    const isin = normalizeId(quote.isin);
    const symbol = normalizeId(quote.symbol);
    if (!isin && !symbol) throw new Error("Every quote needs an ISIN or symbol.");
    if (byIsin.has(isin) || bySymbol.has(symbol)) {
      throw new Error(`Duplicate quote for ${isin || symbol}.`);
    }
    if (!(Number.isFinite(quote.price) && quote.price > 0 &&
          Number.isFinite(quote.previousClose) && quote.previousClose > 0)) {
      throw new Error(`Use positive numeric prices for ${isin || symbol}.`);
    }
    const returnPct = (quote.price - quote.previousClose) / quote.previousClose;
    if (!Number.isFinite(returnPct)) throw new Error(`Invalid price change for ${isin || symbol}.`);
    const normalized = { ...quote, isin, symbol, returnPct };
    if (isin) byIsin.set(isin, normalized);
    if (symbol) bySymbol.set(symbol, normalized);
  }
  return { byIsin, bySymbol };
}

/** All weights/returns are decimal fractions. Market prices must use the same INR basis as the reference close. */
export function estimateNav({ nav, holdings, market }) {
  if (!(Number.isFinite(nav?.value) && nav.value > 0) || !validDate(nav.date)) {
    throw new Error("A positive official NAV and valid NAV date are required.");
  }
  if (market.baseDate !== nav.date) {
    throw new Error(`The reference close must be from the NAV date (${nav.date}).`);
  }
  if (marketSessionDate(market.asOf) <= nav.date) {
    throw new Error("The quote date in India must follow the official NAV date.");
  }
  const { byIsin, bySymbol } = indexQuotes(market.quotes);
  let changePct = 0;
  let coveredWeight = 0;
  let totalWeight = 0;
  const contributions = holdings.map((holding) => {
    const { name, weight } = holding;
    const isin = normalizeId(holding.isin);
    const symbol = normalizeId(holding.symbol);
    if (!Number.isFinite(weight) || weight < 0 || weight > 1) {
      throw new Error(`Invalid portfolio weight for ${name || isin || symbol}.`);
    }
    totalWeight += weight;
    const symbolQuote = bySymbol.get(symbol);
    const matchedBySymbol = symbolQuote && (!isin || !symbolQuote.isin || symbolQuote.isin === isin);
    const quote = byIsin.get(isin) ?? (matchedBySymbol ? symbolQuote : undefined);
    const covered = Boolean(quote && weight > 0);
    const contributionPct = covered ? weight * quote.returnPct : null;
    if (covered) {
      coveredWeight += weight;
      changePct += contributionPct;
    }
    return {
      isin, symbol, name, weight, covered,
      price: quote?.price ?? null,
      previousClose: quote?.previousClose ?? null,
      returnPct: quote?.returnPct ?? null,
      contributionPct,
    };
  });
  // Allow a small overage from rounded disclosed weights without rescaling contributions.
  if (totalWeight > 1.003) throw new Error("Disclosed holding weights exceed 100%. Check the source data.");
  const hasCoverage = coveredWeight > 0;
  const change = hasCoverage ? nav.value * changePct : null;
  const estimate = hasCoverage ? nav.value + change : null;
  if (hasCoverage && (!Number.isFinite(estimate) || estimate <= 0)) {
    throw new Error("The resulting estimate is outside the valid NAV range.");
  }
  return {
    baselineNav: nav.value,
    baselineDate: nav.date,
    estimate,
    change,
    changePct: hasCoverage ? changePct : null,
    coveredWeight: Math.min(coveredWeight, 1),
    uncoveredWeight: Math.max(1 - coveredWeight, 0),
    asOf: market.asOf,
    mode: market.mode,
    contributions,
  };
}

/** A reproducible fictional market session on the next weekday, with no real prices. */
export function createDemoSnapshot({ holdings, baseDate, movePct = -0.015, time = "14:30" }) {
  if (!validDate(baseDate)) throw new Error("A valid NAV date is required for the scenario.");
  if (!Number.isFinite(movePct) || Math.abs(movePct) > 0.5) {
    throw new Error("Enter a scenario move between −50% and +50%.");
  }
  const nextSession = new Date(`${baseDate}T00:00:00Z`);
  do {
    nextSession.setUTCDate(nextSession.getUTCDate() + 1);
  } while (nextSession.getUTCDay() === 0 || nextSession.getUTCDay() === 6);
  const quotes = holdings.filter((holding) => holding.isin || holding.symbol).map((holding, index) => {
    const previousClose = 300 + (index * 97) % 1700;
    const relativeMove = [1.4, 0.8, 1.15, -0.25, 1.25, 0.65, 1.08, 0.85][index % 8];
    return {
      isin: holding.isin,
      symbol: holding.symbol,
      previousClose,
      price: previousClose * (1 + movePct * relativeMove),
    };
  });
  return {
    mode: "simulated",
    asOf: `${nextSession.toISOString().slice(0, 10)}T${time}:00+05:30`,
    baseDate,
    quotes,
  };
}

function parseCsvRows(text) {
  const rows = [];
  let row = [];
  let field = "";
  let inQuotes = false;
  let closedQuote = false;
  for (let i = 0; i < text.length; i += 1) {
    const character = text[i];
    if (inQuotes) {
      if (character === '"' && text[i + 1] === '"') {
        field += '"';
        i += 1;
      } else if (character === '"') {
        inQuotes = false;
        closedQuote = true;
      } else {
        field += character;
      }
    } else if (character === "," || character === "\n" || character === "\r") {
      row.push(field.trim());
      field = "";
      closedQuote = false;
      if (character !== ",") {
        if (character === "\r" && text[i + 1] === "\n") i += 1;
        if (row.some(Boolean)) rows.push(row);
        row = [];
      }
    } else if (character === '"' && field === "" && !closedQuote) {
      inQuotes = true;
    } else {
      if (closedQuote || character === '"') throw new Error("Check the quotation marks in the CSV.");
      field += character;
    }
  }
  if (inQuotes) throw new Error("Close the final quoted CSV field.");
  row.push(field.trim());
  if (row.some(Boolean)) rows.push(row);
  return rows;
}

/** Header columns: isin,symbol,price,previous_close,base_date,as_of. Either ID can be blank. */
export function parseMarketCsv(text) {
  const [headers, ...rows] = parseCsvRows(text.replace(/^\uFEFF/, ""));
  if (!headers || !rows.length) throw new Error("Include a CSV header and at least one quote.");
  const names = headers.map((header) => header.toLowerCase());
  if (new Set(names).size !== names.length || !csvColumns.every((column) => names.includes(column))) {
    throw new Error(`Include these CSV columns: ${csvColumns.join(", ")}.`);
  }
  const indexes = Object.fromEntries(csvColumns.map((name) => [name, names.indexOf(name)]));
  const baseDate = rows[0][indexes.base_date];
  const asOf = rows[0][indexes.as_of];
  if (!validDate(baseDate)) throw new Error("Use YYYY-MM-DD for base_date.");
  if (marketSessionDate(asOf) <= baseDate) throw new Error("The quote date in India must follow base_date.");
  const positiveDecimal = /^(?:\d+(?:\.\d+)?|\.\d+)$/;
  const quotes = rows.map((row, index) => {
    if (row.length !== headers.length) throw new Error(`Check the number of fields in quote row ${index + 1}.`);
    if (row[indexes.base_date] !== baseDate || row[indexes.as_of] !== asOf) {
      throw new Error("Use the same base_date and as_of on every quote row.");
    }
    const price = row[indexes.price];
    const previousClose = row[indexes.previous_close];
    if (!positiveDecimal.test(price) || !positiveDecimal.test(previousClose)) {
      throw new Error(`Use plain decimal prices in quote row ${index + 1}.`);
    }
    return {
      isin: normalizeId(row[indexes.isin]),
      symbol: normalizeId(row[indexes.symbol]),
      price: Number(price),
      previousClose: Number(previousClose),
    };
  });
  indexQuotes(quotes);
  return { mode: "manual", asOf, baseDate, quotes };
}
