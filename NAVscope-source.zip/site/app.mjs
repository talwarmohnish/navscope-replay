import { createDemoSnapshot, estimateNav, parseMarketCsv } from "./market.mjs";

const id = (key) => document.getElementById(key);
const currency = new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", minimumFractionDigits: 4, maximumFractionDigits: 4 });
const currencyChange = new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", signDisplay: "exceptZero" });
const rupees = new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR" });
const percent = new Intl.NumberFormat("en-IN", { style: "percent", minimumFractionDigits: 2, maximumFractionDigits: 2 });
const signed = new Intl.NumberFormat("en-IN", { style: "percent", signDisplay: "exceptZero", minimumFractionDigits: 2, maximumFractionDigits: 2 });
const dateFormat = new Intl.DateTimeFormat("en-IN", { timeZone: "Asia/Kolkata", year: "numeric", month: "short", day: "numeric" });
const timeFormat = new Intl.DateTimeFormat("en-IN", { timeZone: "Asia/Kolkata", dateStyle: "medium", timeStyle: "short" });
const money = (value) => value == null ? "—" : currency.format(value);
const dateLabel = (date) => dateFormat.format(new Date(`${date}T00:00:00Z`));
const signedLabel = (value) => value == null ? "—" : signed.format(value).replace("-", "−");
const direction = (value) => value > 0 ? "gain" : value < 0 ? "loss" : "flat";
const pageSize = 6;
const csvHeader = "isin,symbol,price,previous_close,base_date,as_of";
const offlineSnapshot = document.getElementById("offline-data");
const offlineData = offlineSnapshot ? JSON.parse(offlineSnapshot.textContent) : null;
const replayAnchors = [
  { minute: 555, move: -0.25 }, { minute: 600, move: 0.20 },
  { minute: 645, move: -0.35 }, { minute: 690, move: -0.65 },
  { minute: 735, move: -0.40 }, { minute: 780, move: -1.15 },
  { minute: 825, move: -1.75 }, { minute: 870, move: -1.30 },
  { minute: 900, move: -1.50 }, { minute: 930, move: -0.95 },
];
const replayStepMinutes = 5;
const replayTicks = [];
for (const [index, anchor] of replayAnchors.entries()) {
  const next = replayAnchors[index + 1];
  const end = next?.minute ?? anchor.minute + replayStepMinutes;
  for (let minute = anchor.minute; minute < end; minute += replayStepMinutes) {
    const [hour, remainder] = [Math.floor(minute / 60), minute % 60].map((value) => String(value).padStart(2, "0"));
    const move = next ? anchor.move + (next.move - anchor.move) * (minute - anchor.minute) / (end - anchor.minute) : anchor.move;
    replayTicks.push({ time: `${hour}:${remainder}`, move });
  }
}
const replayModels = new WeakMap();

let data;
let model;
let manualPrices;
let expanded = false;
let sourceRefresh;
let loadNumber = 0;
let replayFrame = -1;
let replayTimer;
let chartData;

function preferredTheme() {
  try {
    const saved = globalThis.localStorage?.getItem("navscope-theme");
    if (saved === "light" || saved === "dark") return saved;
  } catch { /* The demo can be opened from a file with restricted storage. */ }
  return globalThis.matchMedia?.("(prefers-color-scheme: dark)")?.matches ? "dark" : "light";
}

function applyTheme(theme, persist = false) {
  document.documentElement.dataset.theme = theme;
  id("theme-light").setAttribute("aria-pressed", String(theme === "light"));
  id("theme-dark").setAttribute("aria-pressed", String(theme === "dark"));
  id("theme-meta").setAttribute("content", theme === "dark" ? "#161b24" : "#f5f6f8");
  if (persist) {
    try { globalThis.localStorage?.setItem("navscope-theme", theme); }
    catch { /* The theme still applies in the current tab. */ }
    drawReplay();
  }
}

applyTheme(preferredTheme());
id("theme-light").addEventListener("click", () => applyTheme("light", true));
id("theme-dark").addEventListener("click", () => applyTheme("dark", true));

function holdings() {
  return data.portfolio.holdings.map((position) => ({ ...position, weight: position.weightPct / 100 }));
}

function simulate(positions, { move, time }) {
  const market = createDemoSnapshot({ holdings: positions, baseDate: data.nav.date, movePct: move / 100, time });
  return estimateNav({ nav: data.nav, holdings: positions, market });
}

function replaySession() {
  if (!data || data.portfolio.asOf > data.nav.date) return [];
  if (!replayModels.has(data)) {
    const positions = holdings();
    replayModels.set(data, replayTicks.map((tick) => simulate(positions, tick)));
  }
  return replayModels.get(data);
}

function makeCell(row, text, className = "") {
  const cell = row.insertCell();
  cell.textContent = text;
  cell.className = className;
  return cell;
}

function renderHoldings() {
  if (!model) return;
  const sort = id("holdings-sort").value;
  const ranked = [...model.contributions];
  const impact = (row) => row.contributionPct ?? 0;
  const weight = (a, b) => b.weight - a.weight;
  const compare = {
    weight,
    gain: (a, b) => Number(b.covered) - Number(a.covered) || impact(b) - impact(a),
    loss: (a, b) => Number(b.covered) - Number(a.covered) || impact(a) - impact(b),
    impact: (a, b) => Math.abs(impact(b)) - Math.abs(impact(a)),
  };
  ranked.sort((a, b) => compare[sort](a, b) || weight(a, b));
  const largest = Math.max(...ranked.map((row) => Math.abs(impact(row))), 0.00001);
  const list = document.createDocumentFragment();
  for (const position of ranked.slice(0, expanded ? ranked.length : pageSize)) {
    const row = document.createElement("tr");
    const holding = makeCell(row, position.name);
    const code = document.createElement("small");
    code.textContent = position.symbol || position.isin;
    holding.append(code);
    makeCell(row, percent.format(position.weight));
    makeCell(row, position.price == null ? "—" : rupees.format(position.price));
    makeCell(row, signedLabel(position.returnPct), direction(position.returnPct));
    const impactCell = row.insertCell();
    const chart = document.createElement("span");
    chart.className = "impact-cell";
    const track = document.createElement("span");
    track.className = "impact-track";
    track.setAttribute("aria-hidden", "true");
    const fill = document.createElement("i");
    fill.className = direction(position.contributionPct);
    fill.style.width = `${100 * Math.abs(impact(position)) / largest}%`;
    const number = document.createElement("span");
    number.textContent = signedLabel(position.contributionPct);
    number.className = direction(position.contributionPct);
    track.append(fill);
    chart.append(track, number);
    impactCell.append(chart);
    list.append(row);
  }
  id("holding-rows").replaceChildren(list);
  id("show-holdings").hidden = ranked.length <= pageSize;
  id("show-holdings").textContent = expanded ? "Show fewer holdings" : `Show all ${ranked.length} holdings`;
  id("show-holdings").setAttribute("aria-expanded", String(expanded));
}

function renderAum() {
  const reports = data.aum ?? [];
  id("aum-panel").hidden = reports.length < 2;
  if (reports.length < 2) return;
  const [previous, latest] = reports.slice(-2);
  const difference = latest.crore - previous.crore;
  const change = difference / previous.crore;
  id("aum-previous-date").textContent = dateLabel(previous.asOf);
  id("aum-previous").textContent = `${rupees.format(previous.crore)} cr`;
  id("aum-previous-source").href = previous.sourceUrl;
  id("aum-latest-date").textContent = dateLabel(latest.asOf);
  id("aum-latest").textContent = `${rupees.format(latest.crore)} cr`;
  id("aum-latest-source").href = latest.sourceUrl;
  id("aum-change").textContent = `${currencyChange.format(difference).replace("-", "−")} cr · ${signedLabel(change)}`;
  id("aum-change").className = direction(change);
}

function drawReplay() {
  if (manualPrices) return;
  const session = replaySession();
  const picker = id("chart-series");
  if (chartData !== data) {
    const selection = picker.value;
    const navOption = document.createElement("option");
    navOption.value = "nav";
    navOption.textContent = "Estimated NAV";
    const options = [navOption];
    session[0]?.contributions.forEach((position, index) => {
      if (position.price == null) return;
      const option = document.createElement("option");
      option.value = String(index);
      option.textContent = position.name;
      options.push(option);
    });
    picker.replaceChildren(...options);
    picker.value = options.some((option) => option.value === selection) ? selection : "nav";
    chartData = data;
  }
  const isNav = picker.value === "nav";
  const values = session.map((snapshot) => isNav ? snapshot.estimate : snapshot.contributions[Number(picker.value)].price);
  const current = replayFrame >= 0 ? values[replayFrame] : null;
  id("chart-price").textContent = current == null ? "" : isNav ? money(current) : rupees.format(current);
  const canvas = id("replay-plot");
  const context = canvas.getContext?.("2d");
  if (!context || !canvas.clientWidth || !canvas.clientHeight) return;
  const width = canvas.clientWidth;
  const height = canvas.clientHeight;
  const scale = globalThis.devicePixelRatio || 1;
  canvas.width = width * scale;
  canvas.height = height * scale;
  context.scale(scale, scale);
  const top = 12;
  const bottom = height - 24;
  const palette = globalThis.getComputedStyle(canvas);
  const color = (name) => palette.getPropertyValue(name).trim();

  context.fillStyle = color("--muted");
  context.font = "11px system-ui";
  if (!values.length || values[0] == null) {
    context.fillText("Replay prices unavailable", 9, 22);
    return;
  }
  const low = Math.min(...values);
  const high = Math.max(...values);
  const padding = Math.max((high - low) * 0.16, 0.02);
  const floor = low - padding;
  const ceiling = high + padding;
  const levels = [ceiling, (ceiling + floor) / 2, floor];
  const left = 17 + Math.max(...levels.map((level) => context.measureText(rupees.format(level)).width));
  const right = width - 12;
  const x = (index) => left + (right - left) * index / (values.length - 1);
  const y = (value) => top + (bottom - top) * (ceiling - value) / (ceiling - floor);

  context.strokeStyle = color("--chart-grid");
  context.setLineDash([4, 4]);
  for (const level of levels) {
    context.fillText(rupees.format(level), 7, y(level) + 4);
    context.beginPath();
    context.moveTo(left, y(level));
    context.lineTo(right, y(level));
    context.stroke();
  }
  context.setLineDash([]);
  context.lineWidth = 2;
  context.strokeStyle = color("--chart-line");
  context.beginPath();
  values.forEach((value, index) => {
    if (index === 0) context.moveTo(x(index), y(value));
    else context.lineTo(x(index), y(value));
  });
  context.stroke();
  if (current != null) {
    const cursorX = x(replayFrame);
    const cursorY = y(current);
    context.strokeStyle = color("--accent");
    context.lineWidth = 1;
    context.beginPath();
    context.moveTo(cursorX, top);
    context.lineTo(cursorX, bottom);
    context.stroke();
    context.fillStyle = color("--accent");
    context.beginPath();
    context.arc(cursorX, cursorY, 4.5, 0, Math.PI * 2);
    context.fill();
  }
  context.fillStyle = color("--muted");
  context.fillText(replayTicks[0].time, left, height - 6);
  if (right - left > 165) {
    const middle = Math.floor(values.length / 2);
    context.textAlign = "center";
    context.fillText(replayTicks[middle].time, x(middle), height - 6);
  }
  context.textAlign = "right";
  context.fillText(`${replayTicks.at(-1).time} IST`, right, height - 6);
}

function renderReplayControls() {
  const playing = replayTimer !== undefined;
  id("play-replay").textContent = playing ? "Pause replay" : "Play replay";
  id("step-replay").textContent = replayFrame < 0 ? "Go to 09:15" : "Next 5 min";
  id("step-replay").disabled = replayFrame >= replayTicks.length - 1;
  id("replay-time").textContent = manualPrices ? "Imported snapshot" : replayFrame < 0 ? "Manual scenario" : `${replayTicks[replayFrame].time} IST · Simulated`;
  drawReplay();
}

function pauseReplay() {
  if (replayTimer !== undefined) clearInterval(replayTimer);
  replayTimer = undefined;
}

function setReplayFrame(index) {
  replayFrame = index;
  id("shock").value = String(replayTicks[index].move);
  render();
}

function renderCalculation() {
  const result = id("calculation-result");
  const example = id("contribution-example");
  result.textContent = model?.estimate == null ? "Insufficient aligned prices" : `${money(model.baselineNav)} × (1 ${model.changePct < 0 ? "−" : "+"} ${percent.format(Math.abs(model.changePct))}) ≈ ${money(model.estimate)}`;
  const position = model?.contributions.reduce((largest, item) => item.covered && (!largest || Math.abs(item.contributionPct) > Math.abs(largest.contributionPct)) ? item : largest, null);
  example.textContent = position ? `${position.name} · ${percent.format(position.weight)} weight × ${signedLabel(position.returnPct)} price move = ${signedLabel(position.contributionPct).replace("%", " percentage points")} of estimated NAV change.` : "";
  example.hidden = !position;
}

function render() {
  if (!data) return;
  const tick = replayTicks[replayFrame];
  const move = tick?.move ?? Number(id("shock").value);
  model = null;
  if (data.portfolio.asOf <= data.nav.date) {
    if (manualPrices) model = estimateNav({ nav: data.nav, holdings: holdings(), market: manualPrices });
    else if (tick) model = replaySession()[replayFrame];
    else model = simulate(holdings(), { move });
  }
  id("fund-mark").textContent = data.fund.house;
  id("fund-code").textContent = data.fund.code;
  id("fund-name").textContent = data.fund.name;
  id("price-mode").textContent = manualPrices ? "Imported prices" : "Simulated prices";
  id("estimate-value").textContent = money(model?.estimate);
  id("estimate-change").textContent = signedLabel(model?.changePct);
  id("estimate-change").className = direction(model?.changePct);
  const amount = model?.change == null ? "" : currencyChange.format(model.change).replace("-", "−");
  id("estimate-label").textContent = model?.estimate != null ? `${amount} vs. official NAV` : "Insufficient aligned data";
  id("official-nav").textContent = money(data.nav.value);
  id("nav-date").textContent = dateLabel(data.nav.date);
  id("coverage").textContent = model == null ? "—" : percent.format(model.coveredWeight);
  id("coverage-bar").style.width = `${(model?.coveredWeight ?? 0) * 100}%`;
  id("coverage-summary").textContent = model ? `${percent.format(model.coveredWeight)} priced · ${percent.format(model.uncoveredWeight)} unpriced` : "Coverage unavailable";
  id("holdings-date").textContent = dateLabel(data.portfolio.asOf);
  id("holdings-link").href = data.portfolio.sourceUrl;
  id("holdings-link").textContent = data.portfolio.status === "snapshot" ? `${data.fund.house} snapshot` : `${data.fund.house} disclosure`;
  id("portfolio-index").href = data.portfolio.indexUrl;
  id("portfolio-index").textContent = `${data.fund.house} monthly holdings`;
  id("shock-value").textContent = signedLabel(move / 100);
  id("scenario-controls").hidden = Boolean(manualPrices);
  id("manual-meta").hidden = !manualPrices;
  id("market-description").textContent = manualPrices ? "Using the prices you imported." : "Synthetic prices across an illustrative session.";
  if (manualPrices) id("manual-time").textContent = `${timeFormat.format(new Date(manualPrices.asOf))} IST`;
  renderAum();
  renderReplayControls();
  renderCalculation();
  document.querySelectorAll("[data-move]").forEach((button) => {
    button.setAttribute("aria-pressed", String(Number(button.dataset.move) === move));
  });
  if (model) renderHoldings();
  else {
    id("holding-rows").innerHTML = '<tr><td colspan="5">The holdings date is later than the available NAV date.</td></tr>';
    id("show-holdings").hidden = true;
  }
}

async function refreshSources(force = false) {
  if (offlineData || sourceRefresh) return;
  const fund = id("fund-select").value;
  const controller = new AbortController();
  sourceRefresh = controller;
  const button = id("refresh");
  button.disabled = true;
  const enabledLabel = button.lastElementChild;
  enabledLabel.textContent = "Checking sources…";
  try {
    const parameters = new URLSearchParams({ fund });
    if (force) parameters.set("refresh", "1");
    const response = await fetch(`./api/sources?${parameters}`, { cache: "no-store", signal: controller.signal });
    if (!response.ok) throw new Error("The tracker could not load the source data.");
    const incoming = await response.json();
    if (sourceRefresh !== controller) return;
    const clearedPrices = manualPrices && incoming.nav.date !== manualPrices.baseDate;
    if (clearedPrices) manualPrices = undefined;
    data = incoming;
    render();
    const navStatus = { snapshot: "AMFI snapshot", cached: "Last verified AMFI NAV", verified: "AMFI feed" }[data.nav.status];
    const house = incoming.fund.house;
    const portfolioStatus = { snapshot: `${house} snapshot shown. The latest workbook check could not be verified.`, cached: `Last verified ${house} workbook`, verified: `${house} monthly workbook` }[data.portfolio.status];
    const reset = clearedPrices ? " Imported prices were cleared when the NAV valuation date changed." : "";
    id("source-status").textContent = `${navStatus} · ${portfolioStatus}${reset}`;
  } catch (error) {
    if (sourceRefresh !== controller) return;
    id("source-status").textContent = `${error.message} ${data ? "Showing the previous results." : "Try refreshing sources."}`;
    if (!data) id("holding-rows").innerHTML = '<tr><td colspan="5">Source data unavailable.</td></tr>';
  } finally {
    if (sourceRefresh === controller) {
      sourceRefresh = undefined;
      button.disabled = false;
      enabledLabel.textContent = "Refresh sources";
    }
  }
}

id("refresh").addEventListener("click", () => refreshSources(true));
id("fund-select").addEventListener("change", () => loadFund().catch((error) => console.error(error.message)));
id("shock").addEventListener("input", () => { pauseReplay(); replayFrame = -1; render(); });
document.querySelectorAll("[data-move]").forEach((button) => button.addEventListener("click", () => {
  pauseReplay();
  replayFrame = -1;
  id("shock").value = button.dataset.move;
  render();
}));
id("play-replay").addEventListener("click", () => {
  if (!data || manualPrices) return;
  if (replayTimer !== undefined) {
    pauseReplay();
    renderReplayControls();
    return;
  }
  if (replayFrame < 0 || replayFrame >= replayTicks.length - 1) setReplayFrame(0);
  replayTimer = setInterval(() => {
    const next = replayFrame + 1;
    if (next >= replayTicks.length - 1) pauseReplay();
    setReplayFrame(next);
  }, 850);
  renderReplayControls();
});
id("step-replay").addEventListener("click", () => { pauseReplay(); setReplayFrame(Math.min(replayFrame + 1, replayTicks.length - 1)); });
id("reset-replay").addEventListener("click", () => { pauseReplay(); setReplayFrame(0); });
id("chart-series").addEventListener("change", drawReplay);
globalThis.addEventListener?.("resize", drawReplay);
id("holdings-sort").addEventListener("change", renderHoldings);
id("show-holdings").addEventListener("click", () => { expanded = !expanded; renderHoldings(); });
id("back-to-demo").addEventListener("click", () => { manualPrices = undefined; render(); id("shock").focus(); });

const dialog = id("import-dialog");
const importError = id("import-error");
id("open-import").addEventListener("click", () => { importError.hidden = true; dialog.showModal(); });
id("close-import").addEventListener("click", () => dialog.close());
id("csv-template").addEventListener("click", () => {
  const rows = (data?.portfolio.holdings ?? []).map(({ isin, symbol }) => [isin ?? "", symbol ?? "", "", "", data.nav.date, ""].join(","));
  const url = URL.createObjectURL(new Blob([[csvHeader, ...rows].join("\n")], { type: "text/csv" }));
  const link = document.createElement("a");
  link.href = url;
  link.download = "navscope-price-template.csv";
  link.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
});
id("import-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  importError.hidden = true;
  try {
    if (!data) throw new Error("Wait for the fund data to load before applying prices.");
    const file = id("price-file").files[0];
    if (file?.size > 128_000) throw new Error("Use a CSV smaller than 128 KB.");
    const text = file ? await file.text() : id("price-text").value;
    if (text.length > 128_000) throw new Error("Use a CSV smaller than 128 KB.");
    const snapshot = parseMarketCsv(text);
    if (Date.parse(snapshot.asOf) > Date.now()) throw new Error("Use an as-of timestamp from a completed or ongoing market session.");
    const estimate = estimateNav({ nav: data.nav, holdings: holdings(), market: snapshot });
    if (estimate.coveredWeight === 0) throw new Error("No quotes matched the fund’s holdings. Check the ISINs or symbols.");
    pauseReplay();
    manualPrices = snapshot;
    render();
    event.target.reset();
    dialog.close();
  } catch (error) {
    importError.textContent = error.message;
    importError.hidden = false;
  }
});

async function loadFund() {
  pauseReplay();
  id("chart-series").value = "nav";
  const fund = id("fund-select").value;
  const currentLoad = ++loadNumber;
  sourceRefresh?.abort();
  sourceRefresh = undefined;
  data = undefined;
  model = undefined;
  manualPrices = undefined;
  expanded = false;
  if (offlineData) {
    data = offlineData[fund];
    id("refresh").hidden = true;
    id("source-status").textContent = `Offline demo · Bundled AMFI NAV and ${data.fund.house} holdings snapshots.`;
    render();
    return;
  }
  id("source-status").textContent = "Checking official sources…";
  try {
    const response = await fetch(`./api/bootstrap?${new URLSearchParams({ fund })}`);
    const snapshot = response.ok ? await response.json() : null;
    if (snapshot && loadNumber === currentLoad) {
      data = snapshot;
      render();
    }
  } finally {
    if (loadNumber === currentLoad) await refreshSources();
  }
}

loadFund().catch((error) => console.error(error.message));
if (!offlineData) setInterval(() => { if (!document.hidden) refreshSources(); }, 15 * 60 * 1000);
