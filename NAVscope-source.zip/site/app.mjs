import { createDemoSnapshot, estimateNav, parseMarketCsv } from "./market.mjs";

const id = (key) => document.getElementById(key);
const currency = new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", minimumFractionDigits: 4, maximumFractionDigits: 4 });
const currencyChange = new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", signDisplay: "exceptZero" });
const croresFormat = new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", minimumFractionDigits: 2, maximumFractionDigits: 2 });
const percent = new Intl.NumberFormat("en-IN", { style: "percent", minimumFractionDigits: 2, maximumFractionDigits: 2 });
const signed = new Intl.NumberFormat("en-IN", { style: "percent", signDisplay: "exceptZero", minimumFractionDigits: 2, maximumFractionDigits: 2 });
const dateFormat = new Intl.DateTimeFormat("en-IN", { timeZone: "Asia/Kolkata", year: "numeric", month: "short", day: "numeric" });
const timeFormat = new Intl.DateTimeFormat("en-IN", { timeZone: "Asia/Kolkata", dateStyle: "medium", timeStyle: "short" });
const money = (value) => value == null ? "—" : currency.format(value);
const dateLabel = (date) => dateFormat.format(new Date(`${date}T00:00:00Z`));
const signedLabel = (value) => value == null ? "—" : signed.format(value).replace("-", "−");
const direction = (value) => value > 0 ? "gain" : value < 0 ? "loss" : "flat";
const pageSize = 6;
const csvHeader = "isin,symbol,price,previous_close,base_date,as_of";
const offlineSnapshot = document.getElementById("offline-data");
const offlineData = offlineSnapshot ? JSON.parse(offlineSnapshot.textContent) : null;
const replayTicks = [
  { time: "09:15", move: -0.25 }, { time: "10:00", move: 0.20 },
  { time: "10:45", move: -0.35 }, { time: "11:30", move: -0.65 },
  { time: "12:15", move: -0.40 }, { time: "13:00", move: -1.15 },
  { time: "13:45", move: -1.75 }, { time: "14:30", move: -1.30 },
  { time: "15:00", move: -1.50 }, { time: "15:30", move: -0.95 },
];

let data;
let model;
let manualPrices;
let expanded = false;
let sourceRefresh;
let loadNumber = 0;
let replayFrame = -1;
let replayTimer;

function holdings() {
  return data.portfolio.holdings.map((position) => ({ ...position, weight: position.weightPct / 100 }));
}

function makeCell(row, text, className = "") {
  const cell = row.insertCell();
  cell.textContent = text;
  cell.className = className;
  return cell;
}

function renderHoldings() {
  if (!model) return;
  const sort = id("holdings-sort").value;
  const ranked = [...model.contributions];
  const impact = (row) => row.contributionPct ?? 0;
  const weight = (a, b) => b.weight - a.weight;
  const compare = {
    weight,
    gain: (a, b) => Number(b.covered) - Number(a.covered) || impact(b) - impact(a),
    loss: (a, b) => Number(b.covered) - Number(a.covered) || impact(a) - impact(b),
    impact: (a, b) => Math.abs(impact(b)) - Math.abs(impact(a)),
  };
  ranked.sort((a, b) => compare[sort](a, b) || weight(a, b));
  const largest = Math.max(...ranked.map((row) => Math.abs(impact(row))), 0.00001);
  const list = document.createDocumentFragment();
  for (const position of ranked.slice(0, expanded ? ranked.length : pageSize)) {
    const row = document.createElement("tr");
    const holding = makeCell(row, position.name);
    const code = document.createElement("small");
    code.textContent = position.symbol || position.isin;
    holding.append(code);
    makeCell(row, percent.format(position.weight));
    makeCell(row, signedLabel(position.returnPct), direction(position.returnPct));
    const impactCell = row.insertCell();
    const chart = document.createElement("span");
    chart.className = "impact-cell";
    const track = document.createElement("span");
    track.className = "impact-track";
    track.setAttribute("aria-hidden", "true");
    const fill = document.createElement("i");
    fill.className = direction(position.contributionPct);
    fill.style.width = `${100 * Math.abs(impact(position)) / largest}%`;
    const number = document.createElement("span");
    number.textContent = signedLabel(position.contributionPct);
    number.className = direction(position.contributionPct);
    track.append(fill);
    chart.append(track, number);
    impactCell.append(chart);
    list.append(row);
  }
  id("holding-rows").replaceChildren(list);
  id("show-holdings").hidden = ranked.length <= pageSize;
  id("show-holdings").textContent = expanded ? "Show fewer holdings" : `Show all ${ranked.length} holdings`;
  id("show-holdings").setAttribute("aria-expanded", String(expanded));
}

function renderAum() {
  const reports = data.aum ?? [];
  id("aum-panel").hidden = reports.length < 2;
  if (reports.length < 2) return;
  const [previous, latest] = reports.slice(-2);
  const difference = latest.crore - previous.crore;
  const change = difference / previous.crore;
  id("aum-previous-date").textContent = dateLabel(previous.asOf);
  id("aum-previous").textContent = `${croresFormat.format(previous.crore)} cr`;
  id("aum-previous-source").href = previous.sourceUrl;
  id("aum-latest-date").textContent = dateLabel(latest.asOf);
  id("aum-latest").textContent = `${croresFormat.format(latest.crore)} cr`;
  id("aum-latest-source").href = latest.sourceUrl;
  id("aum-change").textContent = `${currencyChange.format(difference).replace("-", "−")} cr · ${signedLabel(change)}`;
  id("aum-change").className = direction(change);
}

function drawReplay() {
  const canvas = id("replay-plot");
  const context = canvas.getContext?.("2d");
  if (!context || !canvas.clientWidth || !canvas.clientHeight) return;
  const width = canvas.clientWidth;
  const height = canvas.clientHeight;
  const scale = globalThis.devicePixelRatio || 1;
  canvas.width = width * scale;
  canvas.height = height * scale;
  context.scale(scale, scale);
  const left = 12;
  const right = width - 12;
  const top = 12;
  const bottom = height - 24;
  const x = (index) => left + (right - left) * index / (replayTicks.length - 1);
  const y = (move) => top + (bottom - top) * (0.4 - move) / 2.5;

  context.strokeStyle = "#d1dfdf";
  context.setLineDash([4, 4]);
  for (const level of [0, -1, -2]) {
    context.beginPath();
    context.moveTo(left, y(level));
    context.lineTo(right, y(level));
    context.stroke();
  }
  context.setLineDash([]);
  context.lineWidth = 2;
  context.strokeStyle = "#648e8a";
  context.beginPath();
  replayTicks.forEach(({ move }, index) => {
    if (index === 0) context.moveTo(x(index), y(move));
    else context.lineTo(x(index), y(move));
  });
  context.stroke();
  if (replayFrame >= 0) {
    const cursorX = x(replayFrame);
    const cursorY = y(replayTicks[replayFrame].move);
    context.strokeStyle = "#087f75";
    context.lineWidth = 1;
    context.beginPath();
    context.moveTo(cursorX, top);
    context.lineTo(cursorX, bottom);
    context.stroke();
    context.fillStyle = "#087f75";
    context.beginPath();
    context.arc(cursorX, cursorY, 4.5, 0, Math.PI * 2);
    context.fill();
  }
  context.fillStyle = "#596e73";
  context.font = "11px system-ui";
  context.fillText("09:15", left, height - 6);
  context.textAlign = "right";
  context.fillText("15:30 IST", right, height - 6);
}

function renderReplayControls() {
  const playing = replayTimer !== undefined;
  id("play-replay").textContent = playing ? "Pause replay" : "Play replay";
  id("step-replay").disabled = replayFrame >= replayTicks.length - 1;
  id("replay-time").textContent = manualPrices ? "Imported snapshot" : replayFrame < 0 ? "Manual scenario" : `${replayTicks[replayFrame].time} IST · Simulated`;
  drawReplay();
}

function pauseReplay() {
  if (replayTimer !== undefined) clearInterval(replayTimer);
  replayTimer = undefined;
}

function setReplayFrame(index) {
  replayFrame = index;
  id("shock").value = String(replayTicks[index].move);
  render();
}

function renderCalculation() {
  const result = id("calculation-result");
  const example = id("contribution-example");
  result.textContent = model?.estimate == null ? "Insufficient aligned prices" : `${money(model.baselineNav)} × (1 ${model.changePct < 0 ? "−" : "+"} ${percent.format(Math.abs(model.changePct))}) ≈ ${money(model.estimate)}`;
  const position = model?.contributions.reduce((largest, item) => item.covered && (!largest || Math.abs(item.contributionPct) > Math.abs(largest.contributionPct)) ? item : largest, null);
  example.textContent = position ? `${position.name} · ${percent.format(position.weight)} weight × ${signedLabel(position.returnPct)} price move = ${signedLabel(position.contributionPct).replace("%", " percentage points")} of estimated NAV change.` : "";
  example.hidden = !position;
}

function render() {
  if (!data) return;
  const move = Number(id("shock").value);
  const positions = holdings();
  const market = manualPrices ?? createDemoSnapshot({ holdings: positions, baseDate: data.nav.date, movePct: move / 100, time: replayTicks[replayFrame]?.time });
  model = data.portfolio.asOf > data.nav.date ? null : estimateNav({ nav: data.nav, holdings: positions, market });
  id("fund-mark").textContent = data.fund.house;
  id("fund-code").textContent = data.fund.code;
  id("fund-name").textContent = data.fund.name;
  id("price-mode").textContent = manualPrices ? "Imported prices" : "Simulated prices";
  id("estimate-value").textContent = money(model?.estimate);
  id("estimate-change").textContent = signedLabel(model?.changePct);
  id("estimate-change").className = direction(model?.changePct);
  const amount = model?.change == null ? "" : currencyChange.format(model.change).replace("-", "−");
  id("estimate-label").textContent = model?.estimate != null ? `${amount} vs. official NAV` : "Insufficient aligned data";
  id("official-nav").textContent = money(data.nav.value);
  id("nav-date").textContent = dateLabel(data.nav.date);
  id("coverage").textContent = model == null ? "—" : percent.format(model.coveredWeight);
  id("coverage-bar").style.width = `${(model?.coveredWeight ?? 0) * 100}%`;
  id("coverage-summary").textContent = model ? `${percent.format(model.coveredWeight)} priced · ${percent.format(model.uncoveredWeight)} unpriced` : "Coverage unavailable";
  id("holdings-date").textContent = dateLabel(data.portfolio.asOf);
  id("holdings-link").href = data.portfolio.sourceUrl;
  id("holdings-link").textContent = data.portfolio.status === "snapshot" ? `${data.fund.house} snapshot` : `${data.fund.house} disclosure`;
  id("portfolio-index").href = data.portfolio.indexUrl;
  id("portfolio-index").textContent = `${data.fund.house} monthly holdings`;
  id("shock-value").textContent = signedLabel(move / 100);
  id("scenario-controls").hidden = Boolean(manualPrices);
  id("manual-meta").hidden = !manualPrices;
  id("market-description").textContent = manualPrices ? "Using the prices you imported." : "Synthetic prices across an illustrative session.";
  if (manualPrices) id("manual-time").textContent = `${timeFormat.format(new Date(manualPrices.asOf))} IST`;
  renderAum();
  renderReplayControls();
  renderCalculation();
  document.querySelectorAll("[data-move]").forEach((button) => {
    button.setAttribute("aria-pressed", String(Number(button.dataset.move) === move));
  });
  if (model) renderHoldings();
  else {
    id("holding-rows").innerHTML = '<tr><td colspan="4">The holdings date is later than the available NAV date.</td></tr>';
    id("show-holdings").hidden = true;
  }
}

async function refreshSources(force = false) {
  if (offlineData || sourceRefresh) return;
  const fund = id("fund-select").value;
  const controller = new AbortController();
  sourceRefresh = controller;
  const button = id("refresh");
  button.disabled = true;
  const enabledLabel = button.lastElementChild;
  enabledLabel.textContent = "Checking sources…";
  try {
    const parameters = new URLSearchParams({ fund });
    if (force) parameters.set("refresh", "1");
    const response = await fetch(`./api/sources?${parameters}`, { cache: "no-store", signal: controller.signal });
    if (!response.ok) throw new Error("The tracker could not load the source data.");
    const incoming = await response.json();
    if (sourceRefresh !== controller) return;
    const clearedPrices = manualPrices && incoming.nav.date !== manualPrices.baseDate;
    if (clearedPrices) manualPrices = undefined;
    data = incoming;
    render();
    const navStatus = { snapshot: "AMFI snapshot", cached: "Last verified AMFI NAV", verified: "AMFI feed" }[data.nav.status];
    const house = incoming.fund.house;
    const portfolioStatus = { snapshot: `${house} snapshot shown. The latest workbook check could not be verified.`, cached: `Last verified ${house} workbook`, verified: `${house} monthly workbook` }[data.portfolio.status];
    const reset = clearedPrices ? " Imported prices were cleared when the NAV valuation date changed." : "";
    id("source-status").textContent = `${navStatus} · ${portfolioStatus}${reset}`;
  } catch (error) {
    if (sourceRefresh !== controller) return;
    id("source-status").textContent = `${error.message} ${data ? "Showing the previous results." : "Try refreshing sources."}`;
    if (!data) id("holding-rows").innerHTML = '<tr><td colspan="4">Source data unavailable.</td></tr>';
  } finally {
    if (sourceRefresh === controller) {
      sourceRefresh = undefined;
      button.disabled = false;
      enabledLabel.textContent = "Refresh sources";
    }
  }
}

id("refresh").addEventListener("click", () => refreshSources(true));
id("fund-select").addEventListener("change", () => loadFund().catch((error) => console.error(error.message)));
id("shock").addEventListener("input", () => { pauseReplay(); replayFrame = -1; render(); });
document.querySelectorAll("[data-move]").forEach((button) => button.addEventListener("click", () => {
  pauseReplay();
  replayFrame = -1;
  id("shock").value = button.dataset.move;
  render();
}));
id("play-replay").addEventListener("click", () => {
  if (!data || manualPrices) return;
  if (replayTimer !== undefined) {
    pauseReplay();
    renderReplayControls();
    return;
  }
  if (replayFrame < 0 || replayFrame >= replayTicks.length - 1) setReplayFrame(0);
  replayTimer = setInterval(() => {
    const next = replayFrame + 1;
    if (next >= replayTicks.length - 1) pauseReplay();
    setReplayFrame(next);
  }, 850);
  renderReplayControls();
});
id("step-replay").addEventListener("click", () => { pauseReplay(); setReplayFrame(Math.min(replayFrame + 1, replayTicks.length - 1)); });
id("reset-replay").addEventListener("click", () => { pauseReplay(); setReplayFrame(0); });
globalThis.addEventListener?.("resize", drawReplay);
id("holdings-sort").addEventListener("change", renderHoldings);
id("show-holdings").addEventListener("click", () => { expanded = !expanded; renderHoldings(); });
id("back-to-demo").addEventListener("click", () => { manualPrices = undefined; render(); id("shock").focus(); });

const dialog = id("import-dialog");
const importError = id("import-error");
id("open-import").addEventListener("click", () => { importError.hidden = true; dialog.showModal(); });
id("close-import").addEventListener("click", () => dialog.close());
id("csv-template").addEventListener("click", () => {
  const rows = (data?.portfolio.holdings ?? []).map(({ isin, symbol }) => [isin ?? "", symbol ?? "", "", "", data.nav.date, ""].join(","));
  const url = URL.createObjectURL(new Blob([[csvHeader, ...rows].join("\n")], { type: "text/csv" }));
  const link = document.createElement("a");
  link.href = url;
  link.download = "navscope-price-template.csv";
  link.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
});
id("import-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  importError.hidden = true;
  try {
    if (!data) throw new Error("Wait for the fund data to load before applying prices.");
    const file = id("price-file").files[0];
    if (file?.size > 128_000) throw new Error("Use a CSV smaller than 128 KB.");
    const text = file ? await file.text() : id("price-text").value;
    if (text.length > 128_000) throw new Error("Use a CSV smaller than 128 KB.");
    const snapshot = parseMarketCsv(text);
    if (Date.parse(snapshot.asOf) > Date.now()) throw new Error("Use an as-of timestamp from a completed or ongoing market session.");
    const estimate = estimateNav({ nav: data.nav, holdings: holdings(), market: snapshot });
    if (estimate.coveredWeight === 0) throw new Error("No quotes matched the fund’s holdings. Check the ISINs or symbols.");
    pauseReplay();
    manualPrices = snapshot;
    render();
    event.target.reset();
    dialog.close();
  } catch (error) {
    importError.textContent = error.message;
    importError.hidden = false;
  }
});

async function loadFund() {
  pauseReplay();
  const fund = id("fund-select").value;
  const currentLoad = ++loadNumber;
  sourceRefresh?.abort();
  sourceRefresh = undefined;
  data = undefined;
  model = undefined;
  manualPrices = undefined;
  expanded = false;
  if (offlineData) {
    data = offlineData[fund];
    id("refresh").hidden = true;
    id("source-status").textContent = `Offline demo · Bundled AMFI NAV and ${data.fund.house} holdings snapshots.`;
    render();
    return;
  }
  id("source-status").textContent = "Checking official sources…";
  try {
    const response = await fetch(`./api/bootstrap?${new URLSearchParams({ fund })}`);
    const snapshot = response.ok ? await response.json() : null;
    if (snapshot && loadNumber === currentLoad) {
      data = snapshot;
      render();
    }
  } finally {
    if (loadNumber === currentLoad) await refreshSources();
  }
}

loadFund().catch((error) => console.error(error.message));
if (!offlineData) setInterval(() => { if (!document.hidden) refreshSources(); }, 15 * 60 * 1000);
