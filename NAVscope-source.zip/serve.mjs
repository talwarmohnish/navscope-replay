import { createServer } from "node:http";
import { Readable } from "node:stream";
import "./build.mjs";

const { default: site } = await import("./dist/server/index.js");
const port = Number(process.env.NAVSCOPE_PORT || 4175);

createServer(async (request, response) => {
  try {
    const result = await site.fetch(new Request(new URL(request.url, `http://localhost:${port}`), { method: request.method }));
    response.writeHead(result.status, Object.fromEntries(result.headers));
    if (!result.body) return response.end();
    Readable.fromWeb(result.body).pipe(response);
  } catch (error) {
    console.error(error.message);
    if (!response.headersSent) response.writeHead(500);
    response.end("Something went wrong");
  }
}).listen(port, "127.0.0.1", () => console.log(`NAVscope: http://127.0.0.1:${port}`));
