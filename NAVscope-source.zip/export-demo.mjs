import { mkdir, readFile, writeFile } from "node:fs/promises";
import { dirname } from "node:path";
import "./build.mjs";

const output = process.argv[2];
if (!output) throw new Error("Provide the output HTML path.");
const { default: site } = await import("./dist/server/index.js");
const snapshot = Object.fromEntries(await Promise.all(["ppfas", "hdfc"].map(async (id) => [id, await (await site.fetch(new Request(`http://localhost/api/bootstrap?fund=${id}`))).json()])));
const read = (path) => readFile(new URL(`site/${path}`, import.meta.url), "utf8");
const [html, css, app, market] = await Promise.all([read("index.html"), read("style.css"), read("app.mjs"), read("market.mjs")]);
const inlineApp = app.replace(/^import[^\n]+\n/, "");
const inlineMarket = market.replace(/^export /gm, "");
const payload = JSON.stringify(snapshot).replaceAll("<", "\\u003c");
const result = html
  .replace('<link rel="stylesheet" href="./style.css">', () => `<style>\n${css}</style>`)
  .replace('  <script type="module" src="./app.mjs"></script>\n', "")
  .replace("</body>", () => `  <script id="offline-data" type="application/json">${payload}</script>\n  <script type="module">\n${inlineMarket}\n${inlineApp}</script>\n</body>`);
await mkdir(dirname(output), { recursive: true });
await writeFile(output, result);
