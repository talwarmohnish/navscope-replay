@echo off
setlocal

set "NAVSCOPE_ROOT=%~dp0"
if not exist "%NAVSCOPE_ROOT%quote-check.mjs" set "NAVSCOPE_ROOT=%~dp0..\work\navscope\"
if not exist "%NAVSCOPE_ROOT%quote-check.mjs" goto missing_project

set "NAVSCOPE_ENV_FILE=%NAVSCOPE_ROOT%.env.local"
if not exist "%NAVSCOPE_ENV_FILE%" (
    >"%NAVSCOPE_ENV_FILE%" echo INDIANAPI_KEY=
    if errorlevel 1 goto write_error
)

start "" notepad.exe "%NAVSCOPE_ENV_FILE%"
if errorlevel 1 goto open_error
exit /b 0

:missing_project
echo Extract NAVscope-source.zip and double-click this setup file inside the extracted folder.
pause
exit /b 1

:write_error
echo Could not create the local key file. Extract the starter to a folder you can edit.
pause
exit /b 1

:open_error
echo Could not open the local key file in Notepad.
pause
exit /b 1
