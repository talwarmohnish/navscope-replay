import { mkdir, readFile, writeFile } from "node:fs/promises";

const fromHere = (path) => new URL(path, import.meta.url);
const read = (path) => readFile(fromHere(path), "utf8");
const assets = {
  "/": ["site/index.html", "text/html; charset=utf-8"],
  "/style.css": ["site/style.css", "text/css; charset=utf-8"],
  "/app.mjs": ["site/app.mjs", "text/javascript; charset=utf-8"],
  "/market.mjs": ["site/market.mjs", "text/javascript; charset=utf-8"],
};
const entries = await Promise.all(Object.entries(assets).map(async ([route, [path, contentType]]) => [route, { contentType, body: await read(path) }]));
const [hdfcModule, ppfasModule, worker, hdfcSnapshot, ppfasSnapshot, aumSnapshots] = await Promise.all([
  read("hdfc-portfolio.mjs"), read("ppfas-portfolio.mjs"), read("worker.mjs"), read("portfolio-fallback.json"), read("ppfas-fallback.json"), read("aum-snapshots.json"),
]);
const output = [
  `const assets = ${JSON.stringify(Object.fromEntries(entries))};`,
  `const snapshotHdfcPortfolio = ${JSON.stringify(JSON.parse(hdfcSnapshot))};`,
  `const snapshotPpfasPortfolio = ${JSON.stringify(JSON.parse(ppfasSnapshot))};`,
  `const reportedAum = ${JSON.stringify(JSON.parse(aumSnapshots))};`,
  hdfcModule,
  ppfasModule.replace(/^import[^\n]*\n/gm, ""),
  worker,
].join("\n\n");

await mkdir(fromHere("dist/server/"), { recursive: true });
await writeFile(fromHere("dist/server/index.js"), output);
